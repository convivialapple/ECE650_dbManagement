from django.apps import AppConfig


class DbExtraConfig(AppConfig):
    name = 'db_extra'
