from django.db import models

# Create your models here.
#The create_ method acts like a add_ method
class ColorManager(models.Manager):
    def create_color(self, color_id, name):
        color = self.get_or_create(color_id = color_id, name = name)
        return color
    
class Color(models.Model):
    color_id = models.IntegerField(primary_key = True)
    name = models.CharField(max_length = 255)
    manager = ColorManager()

class StateManager(models.Manager):
    def create_state(self, state_id, name):
        state = self.get_or_create(state_id = state_id, name = name)
        return state
    
class State(models.Model):
    state_id = models.IntegerField(primary_key = True)
    name = models.CharField(max_length = 255)
    manager = StateManager();

class TeamManager(models.Manager):
    def create_team(self, team_id, name, state_id, color_id, wins, losses):
        team = self.get_or_create(team_id = team_id, name = name, state_id = state_id, color_id = color_id, wins = wins, losses = losses)
        return team

class Team(models.Model):
    team_id = models.IntegerField(primary_key = True)
    name = models.CharField(max_length = 255)
    state_id = models.ForeignKey(State, on_delete = models.CASCADE)
    color_id = models.ForeignKey(Color, on_delete = models.CASCADE)
    wins = models.IntegerField()
    losses = models.IntegerField()
    manager = TeamManager()


class PlayerManager(models.Manager):
    def create_player(self, player_id, team_id, jersery_num, first_name, last_name, mpg, ppg, rpg, apg, spg, bpg):
        player = self.get_or_create(player_id = player_id, team_id = team_id, uniform_num = jersery_num,
                             first_name = first_name, last_name = last_name,
                             mpg = mpg, ppg = ppg, rpg = rpg, apg = apg,
                             spg = spg, bpg = bpg)
        return player

    
class Player(models.Model): #parent class django .db.model.Model
    player_id = models.IntegerField(primary_key = True)
    team_id = models.ForeignKey(Team, on_delete = models.CASCADE)
    uniform_num = models.IntegerField()
    first_name = models.CharField(max_length = 255)
    last_name = models.CharField(max_length = 255)
    mpg = models.IntegerField()
    ppg = models.IntegerField()
    rpg = models.IntegerField()
    apg = models.IntegerField()
    spg = models.DecimalField(max_digits = 32, decimal_places = 1)
    bpg = models.DecimalField(max_digits = 32, decimal_places = 1)
    manager = PlayerManager()
